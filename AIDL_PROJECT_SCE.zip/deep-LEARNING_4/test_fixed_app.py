#!/usr/bin/env python3
"""
Test the fixed audio processing in the web app
"""

import os
import sys
import tempfile
import shutil

def test_fixed_audio_processing():
    """Test the fixed audio processing functionality"""
    print("🧪 Testing Fixed Audio Processing in Web App")
    print("=" * 60)
    
    # Check if input1.mp3 exists
    if not os.path.exists("input1.mp3"):
        print("❌ input1.mp3 not found")
        return False
    
    print("✅ input1.mp3 found")
    
    try:
        # Import the fixed functions from app.py
        sys.path.append('.')
        from app import load_audio_with_torchaudio, live_voice_to_text
        
        # Create a mock models object for testing
        import whisper
        import torch
        from transformers import AutoTokenizer, AutoModelForSeq2SeqLM, AutoModelForTokenClassification, pipeline
        
        print("📥 Loading models for testing...")
        
        # Load minimal models for testing
        whisper_model = whisper.load_model("base")
        
        # Create mock models object
        models = {
            'whisper_model': whisper_model,
            'ner': None,  # Not needed for audio test
            'translation_tokenizer': None,  # Not needed for audio test
            'translation_model': None,  # Not needed for audio test
            'disease_model': None,  # Not needed for audio test
            'label_encoder': None,  # Not needed for audio test
            'df': None,  # Not needed for audio test
            'X_train': None,  # Not needed for audio test
            'device': torch.device("cpu")
        }
        
        print("✅ Models loaded")
        
        # Test 1: Test load_audio_with_torchaudio function
        print("\n🔍 Test 1: Testing load_audio_with_torchaudio function")
        audio_np = load_audio_with_torchaudio("input1.mp3")
        
        if audio_np is not None:
            print(f"✅ Audio loaded successfully: {len(audio_np)} samples")
        else:
            print("❌ Failed to load audio")
            return False
        
        # Test 2: Test live_voice_to_text function
        print("\n🔍 Test 2: Testing live_voice_to_text function")
        transcribed_text = live_voice_to_text(fallback_file="input1.mp3", models=models)
        
        if transcribed_text and transcribed_text not in ["I couldn't understand what you said. Please try again.", "Sorry, I couldn't transcribe the audio.", "Sorry, I couldn't load the audio file."]:
            print(f"✅ Transcription successful!")
            print(f"📝 Transcribed text: '{transcribed_text}'")
            
            # Test 3: Test with temporary file (simulating web upload)
            print("\n🔍 Test 3: Testing with temporary file (web upload simulation)")
            
            # Create a temporary copy of the audio file
            with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as tmp_file:
                shutil.copy2("input1.mp3", tmp_file.name)
                tmp_file_path = tmp_file.name
            
            try:
                # Test transcription with temporary file
                transcribed_text2 = live_voice_to_text(fallback_file=tmp_file_path, models=models)
                
                if transcribed_text2 and transcribed_text2 not in ["I couldn't understand what you said. Please try again.", "Sorry, I couldn't transcribe the audio.", "Sorry, I couldn't load the audio file."]:
                    print(f"✅ Temporary file transcription successful!")
                    print(f"📝 Transcribed text: '{transcribed_text2}'")
                    
                    print("\n🎉 ALL TESTS PASSED!")
                    print("✅ Audio processing is now working correctly")
                    print("✅ Web interface should work with audio uploads")
                    print("✅ The FFmpeg issue has been resolved")
                    
                    return True
                else:
                    print("❌ Temporary file transcription failed")
                    return False
                    
            finally:
                # Clean up temporary file
                if os.path.exists(tmp_file_path):
                    os.unlink(tmp_file_path)
        else:
            print("❌ Transcription failed")
            return False
            
    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Main test function"""
    print("🏥 AI Medical Symptoms Analyzer - Audio Fix Test")
    print("=" * 60)
    
    if test_fixed_audio_processing():
        print("\n🎊 AUDIO PROCESSING FIX SUCCESSFUL!")
        print("✅ The audio transcription issue has been resolved")
        print("✅ Your web interface will now work with audio files")
        print("✅ No FFmpeg installation required")
        
        print("\n🚀 Ready to launch your web app:")
        print("   streamlit run app.py")
        print("   Then upload audio files and test!")
        
    else:
        print("\n❌ AUDIO PROCESSING FIX FAILED")
        print("Please check the error messages above")

if __name__ == "__main__":
    main()

