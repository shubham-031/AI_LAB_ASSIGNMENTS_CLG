#!/usr/bin/env python3
"""
Audio Processing Fix - Works without FFmpeg
This script provides a working solution for audio processing on Windows
"""

import os
import tempfile
import torch
import torchaudio
import whisper
import numpy as np

def load_audio_with_torchaudio(file_path):
    """Load audio using torchaudio and convert to numpy array for Whisper"""
    try:
        # Load audio with torchaudio
        waveform, sample_rate = torchaudio.load(file_path)
        
        # Convert to mono if stereo
        if waveform.shape[0] > 1:
            waveform = torch.mean(waveform, dim=0, keepdim=True)
        
        # Resample to 16kHz if needed (Whisper expects 16kHz)
        if sample_rate != 16000:
            resampler = torchaudio.transforms.Resample(sample_rate, 16000)
            waveform = resampler(waveform)
        
        # Convert to numpy array and flatten
        audio_np = waveform.squeeze().numpy()
        
        return audio_np
        
    except Exception as e:
        print(f"Error loading audio with torchaudio: {e}")
        return None

def transcribe_audio_fixed(audio_file_path):
    """Fixed audio transcription that works without FFmpeg"""
    try:
        print(f"🎵 Processing audio file: {audio_file_path}")
        
        # Load Whisper model
        print("📥 Loading Whisper model...")
        model = whisper.load_model("base")
        print("✅ Whisper model loaded")
        
        # Load audio using torchaudio
        print("📥 Loading audio with torchaudio...")
        audio_np = load_audio_with_torchaudio(audio_file_path)
        
        if audio_np is None:
            print("❌ Failed to load audio")
            return None
        
        print(f"✅ Audio loaded: {len(audio_np)} samples, 16kHz")
        
        # Transcribe using Whisper with numpy array
        print("🎤 Transcribing audio...")
        result = model.transcribe(
            audio_np,  # Pass numpy array directly instead of file path
            language=None,
            task="transcribe",
            beam_size=5,
            temperature=0.0,
            fp16=False
        )
        
        transcribed_text = result["text"].strip()
        detected_language = result.get("language", "unknown")
        
        print(f"🌐 Detected language: {detected_language}")
        print(f"📝 Transcribed text: '{transcribed_text}'")
        
        if transcribed_text:
            print("✅ Transcription successful!")
            return transcribed_text
        else:
            print("❌ No text transcribed")
            return None
            
    except Exception as e:
        print(f"❌ Transcription failed: {e}")
        import traceback
        traceback.print_exc()
        return None

def test_fixed_audio_processing():
    """Test the fixed audio processing"""
    print("🧪 Testing Fixed Audio Processing")
    print("=" * 50)
    
    audio_file = "input1.mp3"
    
    if not os.path.exists(audio_file):
        print(f"❌ Audio file not found: {audio_file}")
        return False
    
    print(f"✅ Audio file found: {audio_file}")
    
    # Test the fixed transcription
    result = transcribe_audio_fixed(audio_file)
    
    if result:
        print(f"\n🎉 SUCCESS!")
        print(f"📝 Transcribed text: '{result}'")
        return True
    else:
        print(f"\n❌ FAILED")
        return False

if __name__ == "__main__":
    test_fixed_audio_processing()

