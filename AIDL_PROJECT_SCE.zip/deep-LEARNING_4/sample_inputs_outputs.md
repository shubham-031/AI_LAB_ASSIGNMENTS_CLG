# 🏥 Medical AI Application - Sample Inputs & Expected Outputs

## ✅ **Sample Test Cases with Expected Results**

### **Test Case 1: Heart Condition**
**Input:**
```
"I suddenly started feeling chest pain while walking, and soon after, I noticed a fast heart rate that made me feel very uncomfortable and anxious."
```

**Expected Output:**
- **Disease:** Heart Attack
- **Specialist:** Cardiologist
- **Severity:** High
- **Confidence:** 85-95%
- **Extracted Symptoms:** chest_pain, fast_heart_rate, anxiety, discomfort

---

### **Test Case 2: Skin Condition**
**Input:**
```
"I have severe itching and skin rash on my arms and chest. Recently, nodal skin eruptions have started appearing, and the irritation is getting worse."
```

**Expected Output:**
- **Disease:** Fungal Infection
- **Specialist:** Dermatologist
- **Severity:** Low
- **Confidence:** 80-90%
- **Extracted Symptoms:** itching, skin_rash, nodal_skin_eruptions, irritation

---

### **Test Case 3: Digestive Issues**
**Input:**
```
"I have been suffering from acidity for the past few days, along with severe stomach pain. I also noticed ulcers on tongue, and sometimes it even leads to vomiting after meals."
```

**Expected Output:**
- **Disease:** GERD
- **Specialist:** Gastroenterologist
- **Severity:** Medium
- **Confidence:** 75-85%
- **Extracted Symptoms:** acidity, stomach_pain, ulcers_on_tongue, vomiting

---

### **Test Case 4: General Illness**
**Input:**
```
"I feel very tired and have high fever. I also have loss of appetite and feel nauseous. I've been experiencing these symptoms for 3 days now."
```

**Expected Output:**
- **Disease:** Common Cold / Viral Infection
- **Specialist:** General Physician
- **Severity:** Medium
- **Confidence:** 70-80%
- **Extracted Symptoms:** fatigue, high_fever, loss_of_appetite, nausea

---

### **Test Case 5: Respiratory Issues**
**Input:**
```
"I have been coughing continuously and have difficulty breathing. I also have chest pain and feel very weak. My breathing is getting worse."
```

**Expected Output:**
- **Disease:** Pneumonia / Bronchial Asthma
- **Specialist:** Pulmonologist
- **Severity:** High
- **Confidence:** 80-90%
- **Extracted Symptoms:** cough, breathlessness, chest_pain, weakness

---

### **Test Case 6: Liver Condition**
**Input:**
```
"I have been feeling very tired and have yellowish skin. My urine is dark and I have been vomiting. I also have pain in my abdomen."
```

**Expected Output:**
- **Disease:** Hepatitis / Chronic Cholestasis
- **Specialist:** Hepatologist
- **Severity:** High
- **Confidence:** 85-95%
- **Extracted Symptoms:** fatigue, yellowish_skin, dark_urine, vomiting, abdominal_pain

---

### **Test Case 7: Allergic Reaction**
**Input:**
```
"I have been sneezing continuously and have chills. I also have shivering and feel very cold. My nose is running constantly."
```

**Expected Output:**
- **Disease:** Allergy
- **Specialist:** Allergist
- **Severity:** Low
- **Confidence:** 75-85%
- **Extracted Symptoms:** continuous_sneezing, chills, shivering, runny_nose

---

### **Test Case 8: Diabetes Symptoms**
**Input:**
```
"I have been feeling very thirsty and urinating frequently. I also have increased appetite and feel very tired. I have been losing weight recently."
```

**Expected Output:**
- **Disease:** Diabetes
- **Specialist:** Endocrinologist
- **Severity:** High
- **Confidence:** 80-90%
- **Extracted Symptoms:** excessive_hunger, polyuria, increased_appetite, fatigue, weight_loss

---

## 🎯 **How to Use the Application**

### **Method 1: Text Input**
1. Open the application: `streamlit run app.py`
2. Select "Text Input" in the sidebar
3. Paste any of the sample inputs above
4. Click "🔍 Analyze Symptoms"
5. View the results

### **Method 2: Audio Input**
1. Select "Audio File Upload" in the sidebar
2. Upload an audio file (MP3, WAV, M4A, OGG)
3. Click "🔍 Analyze Audio"
4. The system will transcribe and analyze

## 📊 **Output Format**

For each input, you'll get:
- **🔍 Extracted Symptoms:** List of identified symptoms
- **🎯 Primary Diagnosis:** Most likely disease
- **👨‍⚕️ Specialist Recommendation:** Recommended doctor type
- **⚠️ Severity Level:** Low/Medium/High
- **📊 Confidence Score:** Percentage confidence
- **📈 Top 3 Predictions:** Alternative possibilities
- **📈 Analysis Details:** Number of matched symptoms

## 🌍 **Multilingual Support**

The application supports:
- English (default)
- Hindi
- Marathi
- French
- Spanish
- Bengali

Select your preferred language in the sidebar for translated responses.

## ⚠️ **Important Note**

This AI system is for informational purposes only and should not replace professional medical advice. Always consult with a qualified healthcare provider for proper diagnosis and treatment.

