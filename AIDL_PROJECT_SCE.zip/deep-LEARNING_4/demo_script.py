#!/usr/bin/env python3
"""
AI Medical Symptoms Analyzer - Demo Script
This script demonstrates the core functionality without the web interface
"""

import pandas as pd
import numpy as np
import torch
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM, AutoModelForTokenClassification, pipeline
from langdetect import detect
import whisper
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
import tensorflow as tf
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense, Dropout, BatchNormalization
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras import regularizers
from rapidfuzz import fuzz
import warnings
warnings.filterwarnings('ignore')

class MedicalAIDemo:
    def __init__(self):
        """Initialize the Medical AI Demo"""
        print("🏥 Initializing AI Medical Symptoms Analyzer Demo...")
        self.load_models()
        self.prepare_data()
        self.train_model()
        print("✅ Demo initialized successfully!")
    
    def load_models(self):
        """Load AI models"""
        print("📥 Loading AI models...")
        
        # Load NER model
        model_name = "HUMADEX/english_medical_ner"
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForTokenClassification.from_pretrained(model_name)
        self.ner = pipeline("ner", model=model, tokenizer=tokenizer, aggregation_strategy="simple")
        
        # Load translation model
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        nllb_model_name = "facebook/nllb-200-distilled-600M"
        self.translation_tokenizer = AutoTokenizer.from_pretrained(nllb_model_name)
        self.translation_model = AutoModelForSeq2SeqLM.from_pretrained(
            nllb_model_name,
            torch_dtype=torch.float32,
            device_map={"": self.device}
        )
        
        # Load Whisper model
        self.whisper_model = whisper.load_model("base")
        
        print("✅ Models loaded successfully!")
    
    def prepare_data(self):
        """Prepare dataset for training"""
        print("📊 Preparing dataset...")
        
        # Load dataset
        self.df = pd.read_csv("Dataset.csv")
        
        # Prepare data
        self.lb = LabelEncoder()
        self.df['prognosis'] = self.lb.fit_transform(self.df['prognosis'])
        
        self.X = self.df.drop(columns=['Specialist','prognosis', 'Severity'])
        self.y = self.df['prognosis']
        
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            self.X, self.y, test_size=0.2, random_state=2
        )
        
        print(f"✅ Dataset prepared: {len(self.df)} samples, {len(self.X.columns)} features")
    
    def train_model(self):
        """Train the disease prediction model"""
        print("🤖 Training disease prediction model...")
        
        # Create model
        self.model = Sequential()
        self.model.add(Dense(64, activation='relu', input_dim=132))
        self.model.add(BatchNormalization())
        self.model.add(Dropout(0.5))
        self.model.add(Dense(32, activation='relu', kernel_regularizer=regularizers.l2(0.01)))
        self.model.add(Dropout(0.4))
        self.model.add(BatchNormalization())
        self.model.add(Dense(41, activation='softmax'))
        
        self.model.compile(loss='sparse_categorical_crossentropy', optimizer='Adam', metrics=['accuracy'])
        
        # Train model
        early_stop = EarlyStopping(monitor='val_accuracy', patience=3, restore_best_weights=True)
        history = self.model.fit(
            self.X_train, self.y_train, 
            epochs=10, 
            validation_data=(X_test, self.y_test), 
            callbacks=[early_stop], 
            batch_size=64, 
            verbose=0
        )
        
        print("✅ Model training completed!")
    
    def enhanced_symptom_extraction(self, text):
        """Enhanced symptom extraction"""
        try:
            # NER extraction
            entities = self.ner(text)
            ner_symptoms = [e['word'].strip() for e in entities if e['entity_group'] in ['PROBLEM', 'SYMPTOM', 'DISEASE']]
            
            # Keyword-based extraction
            symptom_keywords = {
                'fever': ['fever', 'high_fever', 'mild_fever', 'temperature', 'hot'],
                'cough': ['cough', 'coughing', 'dry_cough'],
                'headache': ['headache', 'head_pain', 'migraine', 'head_ache'],
                'pain': ['pain', 'ache', 'sore', 'hurt', 'aching'],
                'stomach_pain': ['stomach_pain', 'abdominal_pain', 'belly_pain', 'stomach_ache'],
                'chest_pain': ['chest_pain', 'chest_discomfort', 'chest_ache', 'chest_hurt'],
                'back_pain': ['back_pain', 'spine_pain', 'back_ache'],
                'joint_pain': ['joint_pain', 'arthritis', 'joint_ache'],
                'fatigue': ['tired', 'fatigue', 'exhausted', 'weakness', 'tiredness'],
                'nausea': ['nausea', 'nauseous', 'sick', 'queasy'],
                'vomiting': ['vomiting', 'vomit', 'throwing_up'],
                'diarrhea': ['diarrhea', 'loose_stools', 'watery_stools'],
                'constipation': ['constipation', 'hard_stools'],
                'breathlessness': ['breathlessness', 'shortness_of_breath', 'difficulty_breathing'],
                'fast_heart_rate': ['fast_heart_rate', 'palpitations', 'heart_racing', 'rapid_heartbeat'],
                'skin_rash': ['skin_rash', 'rash', 'skin_irritation', 'dermatitis'],
                'itching': ['itching', 'itchy', 'pruritus'],
                'swelling': ['swelling', 'swollen', 'edema'],
                'dizziness': ['dizziness', 'vertigo', 'lightheaded', 'dizzy'],
                'anxiety': ['anxiety', 'anxious', 'nervous', 'worried'],
                'sweating': ['sweating', 'sweat', 'perspiration'],
                'weakness': ['weakness', 'weak', 'feeling_weak']
            }
            
            extracted_symptoms = []
            text_lower = text.lower()
            
            for category, keywords in symptom_keywords.items():
                for keyword in keywords:
                    if keyword in text_lower:
                        extracted_symptoms.append(category)
                        break
            
            # Specific symptom detection
            if 'chest' in text_lower and ('pain' in text_lower or 'hurt' in text_lower or 'ache' in text_lower):
                extracted_symptoms.append('chest_pain')
            
            if ('heart' in text_lower and ('rate' in text_lower or 'beat' in text_lower or 'racing' in text_lower)) or 'palpitations' in text_lower:
                extracted_symptoms.append('fast_heart_rate')
            
            if 'anxious' in text_lower or 'anxiety' in text_lower or 'nervous' in text_lower:
                extracted_symptoms.append('anxiety')
            
            all_symptoms = list(set(ner_symptoms + extracted_symptoms))
            return all_symptoms
            
        except Exception as e:
            print(f"Symptom extraction error: {e}")
            return []
    
    def predict_disease(self, symptoms):
        """Predict disease with confidence scores"""
        try:
            # Create feature vector
            num_features = 132
            x_sample = np.zeros(num_features, dtype=np.float32)
            
            # Match symptoms with dataset features
            symptom_indices = []
            for i, col in enumerate(self.X_train.columns):
                for sym in symptoms:
                    similarity_scores = [
                        fuzz.partial_ratio(sym.lower(), col.lower()),
                        fuzz.ratio(sym.lower(), col.lower()),
                        fuzz.token_sort_ratio(sym.lower(), col.lower())
                    ]
                    max_similarity = max(similarity_scores)
                    
                    if max_similarity > 70:
                        symptom_indices.append(i)
                        break
            
            # Set matched symptoms
            for idx in symptom_indices:
                x_sample[idx] = 1.0
            
            x_sample = x_sample.reshape(1, -1).astype(np.float32)
            
            # Get prediction
            prediction = self.model.predict(x_sample, verbose=0)
            predicted_class = np.argmax(prediction)
            confidence = np.max(prediction)
            
            # Get top 3 predictions
            top3_indices = np.argsort(prediction[0])[-3:][::-1]
            top3_diseases = []
            for idx in top3_indices:
                disease_name = self.lb.classes_[idx]
                disease_confidence = prediction[0][idx]
                top3_diseases.append({
                    'disease': disease_name,
                    'confidence': float(disease_confidence)
                })
            
            # Get specialist and severity
            disease_indices = self.df.index[self.df['prognosis'] == predicted_class]
            if len(disease_indices) > 0:
                first_index = disease_indices[0]
                specialist = self.df['Specialist'].iloc[first_index]
                severity = self.df['Severity'].iloc[first_index]
            else:
                specialist = "General Physician"
                severity = "Medium"
            
            return {
                'primary_disease': self.lb.classes_[predicted_class],
                'specialist': specialist,
                'severity': severity,
                'confidence': float(confidence),
                'top3_diseases': top3_diseases,
                'matched_symptoms': len(symptom_indices)
            }
            
        except Exception as e:
            print(f"Prediction error: {e}")
            return None
    
    def translate_text(self, text, target_language):
        """Translate text to target language"""
        try:
            if target_language == "English":
                return text
            
            lang_map = {
                "English": "eng_Latn",
                "Hindi": "hin_Deva",
                "Marathi": "mar_Deva",
                "French": "fra_Latn",
                "Spanish": "spa_Latn",
                "Bengali": "ben_Beng"
            }
            
            langdetect_map = {
                "en": "eng_Latn",
                "hi": "hin_Deva",
                "mr": "mar_Deva",
                "fr": "fra_Latn",
                "es": "spa_Latn",
                "bn": "ben_Beng"
            }
            
            detected_lang = detect(text)
            detected_code = langdetect_map.get(detected_lang, "eng_Latn")
            target_code = lang_map.get(target_language, "eng_Latn")
            
            if detected_code == target_code:
                return text
            
            self.translation_tokenizer.src_lang = detected_code
            inputs = self.translation_tokenizer(text, return_tensors="pt").to(self.device)
            
            output = self.translation_model.generate(
                **inputs,
                forced_bos_token_id=self.translation_tokenizer.convert_tokens_to_ids(target_code),
                max_new_tokens=256,
                num_beams=4,
                length_penalty=1.5,
                no_repeat_ngram_size=3,
                do_sample=False,
                temperature=0.7
            )
            
            result = self.translation_tokenizer.decode(output[0], skip_special_tokens=True)
            return result if result.strip() else text
            
        except Exception as e:
            print(f"Translation error: {e}")
            return text
    
    def process_audio(self, audio_file):
        """Process audio file and return transcription"""
        try:
            result = self.whisper_model.transcribe(
                audio_file,
                language=None,
                task="transcribe",
                beam_size=5,
                temperature=0.0,
            )
            return result["text"].strip()
        except Exception as e:
            print(f"Audio processing error: {e}")
            return None
    
    def run_demo(self):
        """Run the demo with sample inputs"""
        print("\n🎯 AI Medical Symptoms Analyzer Demo")
        print("=" * 50)
        
        # Test cases
        test_cases = [
            {
                "name": "Heart Condition",
                "symptoms": "I suddenly started feeling chest pain while walking, and soon after, I noticed a fast heart rate that made me feel very uncomfortable and anxious.",
                "expected": "Heart Attack"
            },
            {
                "name": "Skin Condition", 
                "symptoms": "I have severe itching and skin rash on my arms and chest. Recently, nodal skin eruptions have started appearing, and the irritation is getting worse.",
                "expected": "Fungal Infection"
            },
            {
                "name": "Digestive Issues",
                "symptoms": "I have been suffering from acidity for the past few days, along with severe stomach pain. I also noticed ulcers on tongue, and sometimes it even leads to vomiting after meals.",
                "expected": "GERD"
            },
            {
                "name": "General Illness",
                "symptoms": "I feel very tired and have high fever. I also have loss of appetite and feel nauseous. I've been experiencing these symptoms for 3 days now.",
                "expected": "General illness"
            }
        ]
        
        for i, test_case in enumerate(test_cases, 1):
            print(f"\n🔍 Test Case {i}: {test_case['name']}")
            print(f"Input: {test_case['symptoms']}")
            print("-" * 50)
            
            # Extract symptoms
            symptoms = self.enhanced_symptom_extraction(test_case['symptoms'])
            print(f"✅ Extracted Symptoms: {symptoms}")
            
            if symptoms:
                # Predict disease
                prediction = self.predict_disease(symptoms)
                
                if prediction:
                    print(f"🎯 Predicted Disease: {prediction['primary_disease']}")
                    print(f"👨‍⚕️ Recommended Specialist: {prediction['specialist']}")
                    print(f"⚠️ Severity: {prediction['severity']}")
                    print(f"📊 Confidence: {prediction['confidence']:.1%}")
                    print(f"🔢 Matched Symptoms: {prediction['matched_symptoms']}")
                    
                    print("📊 Top 3 Predictions:")
                    for j, disease in enumerate(prediction['top3_diseases'], 1):
                        print(f"   {j}. {disease['disease']} - {disease['confidence']:.1%}")
                    
                    # Check if prediction matches expected
                    if test_case['expected'].lower() in prediction['primary_disease'].lower():
                        print("✅ PREDICTION MATCHES EXPECTED RESULT!")
                    else:
                        print("⚠️ Prediction differs from expected, but may still be valid")
                else:
                    print("❌ Failed to make prediction")
            else:
                print("❌ No symptoms extracted")
        
        # Test multilingual support
        print(f"\n🌍 Testing Multilingual Support")
        print("-" * 50)
        
        test_text = "I have fever and headache"
        languages = ["English", "Hindi", "Marathi"]
        
        for lang in languages:
            try:
                translated = self.translate_text(test_text, lang)
                print(f"🌍 {lang}: {translated}")
            except Exception as e:
                print(f"❌ Translation error for {lang}: {e}")
        
        # Test audio processing if file exists
        print(f"\n🎤 Testing Audio Processing")
        print("-" * 50)
        
        try:
            if os.path.exists("input1.mp3"):
                print("🎵 Processing existing audio file...")
                transcribed = self.process_audio("input1.mp3")
                if transcribed:
                    print(f"✅ Transcription: {transcribed}")
                    
                    # Analyze transcribed text
                    symptoms = self.enhanced_symptom_extraction(transcribed)
                    if symptoms:
                        prediction = self.predict_disease(symptoms)
                        if prediction:
                            print(f"🎯 Voice Analysis Result: {prediction['primary_disease']}")
                            print(f"👨‍⚕️ Specialist: {prediction['specialist']}")
                else:
                    print("❌ Failed to transcribe audio")
            else:
                print("ℹ️ No audio file found for testing")
        except Exception as e:
            print(f"❌ Audio processing error: {e}")
        
        print(f"\n🎉 Demo completed successfully!")
        print("=" * 50)

def main():
    """Main function"""
    try:
        # Initialize demo
        demo = MedicalAIDemo()
        
        # Run demo
        demo.run_demo()
        
    except Exception as e:
        print(f"❌ Demo failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    import os
    main()



