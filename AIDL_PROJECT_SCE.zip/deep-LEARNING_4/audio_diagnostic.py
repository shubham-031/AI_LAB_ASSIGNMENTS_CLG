#!/usr/bin/env python3
"""
Audio Processing Diagnostic Script
This script will identify and fix the audio transcription issue
"""

import os
import sys
import tempfile
import subprocess
import whisper
import torch
import torchaudio
import numpy as np
from pathlib import Path

def check_audio_file():
    """Check if audio file exists and get its properties"""
    print("🔍 Checking Audio File...")
    
    audio_file = "input1.mp3"
    
    if not os.path.exists(audio_file):
        print(f"❌ Audio file not found: {audio_file}")
        return False
    
    print(f"✅ Audio file found: {audio_file}")
    
    # Get file properties
    file_size = os.path.getsize(audio_file)
    print(f"📁 File size: {file_size:,} bytes ({file_size/1024/1024:.2f} MB)")
    
    # Check file extension
    file_ext = os.path.splitext(audio_file)[1].lower()
    print(f"📄 File extension: {file_ext}")
    
    # Check if it's a valid audio file
    try:
        import librosa
        print("✅ Librosa available for audio analysis")
        
        # Try to load with librosa
        y, sr = librosa.load(audio_file, sr=None)
        print(f"🎵 Audio properties: {len(y)} samples, {sr} Hz sample rate")
        print(f"⏱️ Duration: {len(y)/sr:.2f} seconds")
        
        return True
        
    except ImportError:
        print("⚠️ Librosa not available, trying alternative methods")
        
        # Try with torchaudio
        try:
            waveform, sample_rate = torchaudio.load(audio_file)
            print(f"🎵 Audio properties: {waveform.shape} shape, {sample_rate} Hz sample rate")
            print(f"⏱️ Duration: {waveform.shape[1]/sample_rate:.2f} seconds")
            return True
            
        except Exception as e:
            print(f"❌ Torchaudio failed: {e}")
            return False
            
    except Exception as e:
        print(f"❌ Audio analysis failed: {e}")
        return False

def test_whisper_direct():
    """Test Whisper directly with the audio file"""
    print("\n🎤 Testing Whisper Directly...")
    
    audio_file = "input1.mp3"
    
    try:
        # Load Whisper model
        print("📥 Loading Whisper model...")
        model = whisper.load_model("base")
        print("✅ Whisper model loaded")
        
        # Test transcription
        print("🎵 Transcribing audio...")
        result = model.transcribe(
            audio_file,
            language=None,  # Auto-detect
            task="transcribe",
            beam_size=5,
            temperature=0.0,
            fp16=False  # Use FP32 for better compatibility
        )
        
        transcribed_text = result["text"].strip()
        detected_language = result.get("language", "unknown")
        
        print(f"🌐 Detected language: {detected_language}")
        print(f"📝 Transcribed text: '{transcribed_text}'")
        
        if transcribed_text:
            print("✅ Whisper transcription successful!")
            return transcribed_text
        else:
            print("❌ Whisper returned empty text")
            return None
            
    except Exception as e:
        print(f"❌ Whisper transcription failed: {e}")
        import traceback
        traceback.print_exc()
        return None

def test_whisper_with_conversion():
    """Test Whisper with audio format conversion"""
    print("\n🔄 Testing Whisper with Format Conversion...")
    
    audio_file = "input1.mp3"
    
    try:
        # Load Whisper model
        print("📥 Loading Whisper model...")
        model = whisper.load_model("base")
        print("✅ Whisper model loaded")
        
        # Convert to WAV format first
        print("🔄 Converting audio format...")
        temp_wav = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
        temp_wav_path = temp_wav.name
        temp_wav.close()
        
        # Use ffmpeg to convert (if available)
        try:
            subprocess.run([
                "ffmpeg", "-i", audio_file, "-acodec", "pcm_s16le", 
                "-ar", "16000", "-ac", "1", temp_wav_path, "-y"
            ], check=True, capture_output=True)
            print("✅ Audio converted to WAV format")
            
            # Test transcription with converted file
            print("🎵 Transcribing converted audio...")
            result = model.transcribe(
                temp_wav_path,
                language=None,
                task="transcribe",
                beam_size=5,
                temperature=0.0,
                fp16=False
            )
            
            transcribed_text = result["text"].strip()
            detected_language = result.get("language", "unknown")
            
            print(f"🌐 Detected language: {detected_language}")
            print(f"📝 Transcribed text: '{transcribed_text}'")
            
            if transcribed_text:
                print("✅ Whisper transcription with conversion successful!")
                return transcribed_text
            else:
                print("❌ Whisper returned empty text after conversion")
                return None
                
        except subprocess.CalledProcessError as e:
            print(f"❌ FFmpeg conversion failed: {e}")
            print("💡 FFmpeg not available, trying direct approach")
            return None
            
        except FileNotFoundError:
            print("❌ FFmpeg not found")
            print("💡 FFmpeg not available, trying direct approach")
            return None
            
        finally:
            # Clean up temp file
            if os.path.exists(temp_wav_path):
                os.unlink(temp_wav_path)
                
    except Exception as e:
        print(f"❌ Whisper with conversion failed: {e}")
        import traceback
        traceback.print_exc()
        return None

def test_whisper_with_torchaudio():
    """Test Whisper with torchaudio preprocessing"""
    print("\n🔧 Testing Whisper with TorchAudio Preprocessing...")
    
    audio_file = "input1.mp3"
    
    try:
        # Load audio with torchaudio
        print("📥 Loading audio with torchaudio...")
        waveform, sample_rate = torchaudio.load(audio_file)
        print(f"✅ Audio loaded: {waveform.shape}, {sample_rate} Hz")
        
        # Resample to 16kHz if needed
        if sample_rate != 16000:
            print(f"🔄 Resampling from {sample_rate} Hz to 16000 Hz...")
            resampler = torchaudio.transforms.Resample(sample_rate, 16000)
            waveform = resampler(waveform)
            sample_rate = 16000
            print("✅ Audio resampled")
        
        # Convert to mono if stereo
        if waveform.shape[0] > 1:
            print("🔄 Converting to mono...")
            waveform = torch.mean(waveform, dim=0, keepdim=True)
            print("✅ Audio converted to mono")
        
        # Save as temporary WAV file
        temp_wav = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
        temp_wav_path = temp_wav.name
        temp_wav.close()
        
        print("💾 Saving processed audio...")
        torchaudio.save(temp_wav_path, waveform, sample_rate)
        print("✅ Processed audio saved")
        
        # Load Whisper model
        print("📥 Loading Whisper model...")
        model = whisper.load_model("base")
        print("✅ Whisper model loaded")
        
        # Test transcription
        print("🎵 Transcribing processed audio...")
        result = model.transcribe(
            temp_wav_path,
            language=None,
            task="transcribe",
            beam_size=5,
            temperature=0.0,
            fp16=False
        )
        
        transcribed_text = result["text"].strip()
        detected_language = result.get("language", "unknown")
        
        print(f"🌐 Detected language: {detected_language}")
        print(f"📝 Transcribed text: '{transcribed_text}'")
        
        if transcribed_text:
            print("✅ Whisper transcription with preprocessing successful!")
            return transcribed_text
        else:
            print("❌ Whisper returned empty text after preprocessing")
            return None
            
    except Exception as e:
        print(f"❌ Whisper with preprocessing failed: {e}")
        import traceback
        traceback.print_exc()
        return None
        
    finally:
        # Clean up temp file
        if 'temp_wav_path' in locals() and os.path.exists(temp_wav_path):
            os.unlink(temp_wav_path)

def test_file_paths():
    """Test different file path approaches"""
    print("\n📁 Testing File Path Approaches...")
    
    audio_file = "input1.mp3"
    
    # Test different path formats
    path_variations = [
        audio_file,  # Relative path
        os.path.abspath(audio_file),  # Absolute path
        os.path.join(os.getcwd(), audio_file),  # Full path
        Path(audio_file).resolve(),  # Pathlib resolved
    ]
    
    for i, path in enumerate(path_variations, 1):
        print(f"\n🔍 Test {i}: {path}")
        
        if os.path.exists(path):
            print("✅ File exists")
            print(f"📁 File size: {os.path.getsize(path):,} bytes")
            
            # Test if Whisper can access it
            try:
                model = whisper.load_model("base")
                result = model.transcribe(
                    str(path),
                    language=None,
                    task="transcribe",
                    beam_size=1,  # Faster for testing
                    temperature=0.0,
                    fp16=False
                )
                
                if result["text"].strip():
                    print("✅ Whisper can access and transcribe")
                    return str(path)
                else:
                    print("❌ Whisper returns empty text")
                    
            except Exception as e:
                print(f"❌ Whisper access failed: {e}")
        else:
            print("❌ File does not exist")

def main():
    """Main diagnostic function"""
    print("🔧 AUDIO PROCESSING DIAGNOSTIC")
    print("=" * 50)
    
    # Check audio file
    if not check_audio_file():
        print("❌ Cannot proceed without valid audio file")
        return
    
    # Test different approaches
    approaches = [
        ("Direct Whisper", test_whisper_direct),
        ("File Path Testing", test_file_paths),
        ("Whisper with Conversion", test_whisper_with_conversion),
        ("Whisper with Preprocessing", test_whisper_with_torchaudio),
    ]
    
    successful_approach = None
    
    for approach_name, test_func in approaches:
        print(f"\n{'='*20} {approach_name} {'='*20}")
        try:
            result = test_func()
            if result:
                print(f"🎉 SUCCESS with {approach_name}!")
                successful_approach = (approach_name, result)
                break
        except Exception as e:
            print(f"❌ {approach_name} failed: {e}")
    
    # Summary
    print("\n" + "="*50)
    print("📊 DIAGNOSTIC SUMMARY")
    print("="*50)
    
    if successful_approach:
        approach_name, result = successful_approach
        print(f"✅ WORKING APPROACH: {approach_name}")
        print(f"📝 Transcription result: '{result}'")
        print("\n💡 RECOMMENDATION:")
        print(f"Use the {approach_name} method in your application")
        
        # Generate fix code
        if approach_name == "Direct Whisper":
            print("\n🔧 FIX: Update your app.py to use direct Whisper approach")
        elif approach_name == "Whisper with Preprocessing":
            print("\n🔧 FIX: Update your app.py to use torchaudio preprocessing")
        elif approach_name == "Whisper with Conversion":
            print("\n🔧 FIX: Update your app.py to use FFmpeg conversion")
            
    else:
        print("❌ NO WORKING APPROACH FOUND")
        print("\n🔧 TROUBLESHOOTING SUGGESTIONS:")
        print("1. Check if the audio file is corrupted")
        print("2. Try with a different audio file")
        print("3. Install FFmpeg for audio conversion")
        print("4. Check Whisper model installation")
        print("5. Verify audio file format compatibility")

if __name__ == "__main__":
    main()

