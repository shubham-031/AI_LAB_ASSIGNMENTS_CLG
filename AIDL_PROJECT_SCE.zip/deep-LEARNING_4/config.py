"""
Configuration file for AI Medical Symptoms Analyzer
"""

# Model Configuration
MODEL_CONFIG = {
    "ner_model": "HUMADEX/english_medical_ner",
    "translation_model": "facebook/nllb-200-distilled-600M",
    "whisper_model": "base",  # Options: tiny, base, small, medium, large
    "disease_model_epochs": 10,
    "disease_model_batch_size": 64,
    "confidence_threshold": 70,
    "max_translation_tokens": 256,
    "translation_beams": 4
}

# Language Configuration
LANGUAGES = {
    "English": "eng_Latn",
    "Hindi": "hin_Deva", 
    "Marathi": "mar_Deva",
    "French": "fra_Latn",
    "Spanish": "spa_Latn",
    "Bengali": "ben_Beng"
}

LANGDETECT_MAP = {
    "en": "eng_Latn",
    "hi": "hin_Deva",
    "mr": "mar_Deva", 
    "fr": "fra_Latn",
    "es": "spa_Latn",
    "bn": "ben_Beng"
}

# UI Configuration
UI_CONFIG = {
    "page_title": "AI Medical Symptoms Analyzer",
    "page_icon": "🏥",
    "layout": "wide",
    "initial_sidebar_state": "expanded",
    "supported_audio_formats": ["mp3", "wav", "m4a", "ogg"],
    "max_audio_file_size_mb": 50
}

# System Configuration
SYSTEM_CONFIG = {
    "min_ram_gb": 8,
    "recommended_ram_gb": 16,
    "cache_models": True,
    "gpu_acceleration": True,
    "debug_mode": False
}

# Disease and Specialist Mapping
SPECIALIST_MAPPING = {
    "Heart Attack": "Cardiologist",
    "Hypertension": "Cardiologist", 
    "Fungal infection": "Dermatologist",
    "Allergy": "Allergist",
    "GERD": "Gastroenterologist",
    "Diabetes": "Endocrinologist",
    "Migraine": "Neurologist",
    "Pneumonia": "Pulmonologist",
    "Tuberculosis": "Pulmonologist",
    "Hepatitis": "Hepatologist",
    "Arthritis": "Rheumatologist",
    "Default": "General Physician"
}

SEVERITY_MAPPING = {
    "Heart Attack": "High",
    "Hypertension": "High",
    "Fungal infection": "Low",
    "Allergy": "Low", 
    "GERD": "Medium",
    "Diabetes": "High",
    "Migraine": "Medium",
    "Pneumonia": "High",
    "Tuberculosis": "High",
    "Hepatitis": "High",
    "Arthritis": "Medium",
    "Default": "Medium"
}

# Symptom Keywords for Enhanced Extraction
SYMPTOM_KEYWORDS = {
    'fever': ['fever', 'high_fever', 'mild_fever', 'temperature', 'hot'],
    'cough': ['cough', 'coughing', 'dry_cough'],
    'headache': ['headache', 'head_pain', 'migraine', 'head_ache'],
    'pain': ['pain', 'ache', 'sore', 'hurt', 'aching'],
    'stomach_pain': ['stomach_pain', 'abdominal_pain', 'belly_pain', 'stomach_ache'],
    'chest_pain': ['chest_pain', 'chest_discomfort', 'chest_ache', 'chest_hurt'],
    'back_pain': ['back_pain', 'spine_pain', 'back_ache'],
    'joint_pain': ['joint_pain', 'arthritis', 'joint_ache'],
    'fatigue': ['tired', 'fatigue', 'exhausted', 'weakness', 'tiredness'],
    'nausea': ['nausea', 'nauseous', 'sick', 'queasy'],
    'vomiting': ['vomiting', 'vomit', 'throwing_up'],
    'diarrhea': ['diarrhea', 'loose_stools', 'watery_stools'],
    'constipation': ['constipation', 'hard_stools'],
    'breathlessness': ['breathlessness', 'shortness_of_breath', 'difficulty_breathing', 'breathing_problems'],
    'fast_heart_rate': ['fast_heart_rate', 'palpitations', 'heart_racing', 'rapid_heartbeat', 'heart_beat', 'heartbeat'],
    'skin_rash': ['skin_rash', 'rash', 'skin_irritation', 'dermatitis'],
    'itching': ['itching', 'itchy', 'pruritus'],
    'swelling': ['swelling', 'swollen', 'edema'],
    'dizziness': ['dizziness', 'vertigo', 'lightheaded', 'dizzy'],
    'anxiety': ['anxiety', 'anxious', 'nervous', 'worried'],
    'sweating': ['sweating', 'sweat', 'perspiration'],
    'weakness': ['weakness', 'weak', 'feeling_weak']
}

# Sample Test Cases
TEST_CASES = [
    {
        "name": "Heart Condition",
        "symptoms": "I suddenly started feeling chest pain while walking, and soon after, I noticed a fast heart rate that made me feel very uncomfortable and anxious.",
        "expected": "Heart Attack"
    },
    {
        "name": "Skin Condition", 
        "symptoms": "I have severe itching and skin rash on my arms and chest. Recently, nodal skin eruptions have started appearing, and the irritation is getting worse.",
        "expected": "Fungal Infection"
    },
    {
        "name": "Digestive Issues",
        "symptoms": "I have been suffering from acidity for the past few days, along with severe stomach pain. I also noticed ulcers on tongue, and sometimes it even leads to vomiting after meals.",
        "expected": "GERD"
    },
    {
        "name": "General Illness",
        "symptoms": "I feel very tired and have high fever. I also have loss of appetite and feel nauseous. I've been experiencing these symptoms for 3 days now.",
        "expected": "General illness"
    }
]



