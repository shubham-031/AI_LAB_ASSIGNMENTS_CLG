#!/usr/bin/env python3
"""
Final Verification Script for AI Medical Symptoms Analyzer
This script performs final checks and provides launch instructions
"""

import os
import sys
import subprocess
import time

def check_files():
    """Check if all required files exist"""
    print("📁 Checking Required Files...")
    
    required_files = {
        'app.py': 'Main Streamlit application',
        'requirements.txt': 'Python dependencies',
        'README.md': 'Documentation',
        'Dataset.csv': 'Medical symptoms dataset',
        'config.py': 'Configuration file',
        'run_app.py': 'Python launcher script',
        'demo_script.py': 'Demo script',
        'comprehensive_test.py': 'Test suite',
        'run_app.bat': 'Windows launcher',
        'run_app.sh': 'Linux/Mac launcher'
    }
    
    missing_files = []
    present_files = []
    
    for file, description in required_files.items():
        if os.path.exists(file):
            present_files.append(f"✅ {file} - {description}")
        else:
            missing_files.append(f"❌ {file} - {description}")
    
    print("\n📋 File Status:")
    for file_status in present_files:
        print(f"   {file_status}")
    
    if missing_files:
        print("\n⚠️ Missing Files:")
        for file_status in missing_files:
            print(f"   {file_status}")
        return False
    else:
        print("\n✅ All required files are present!")
        return True

def check_dependencies():
    """Check if required Python packages are installed"""
    print("\n📦 Checking Dependencies...")
    
    required_packages = [
        'streamlit', 'pandas', 'numpy', 'torch', 'transformers',
        'langdetect', 'whisper', 'matplotlib', 'seaborn', 'scikit-learn',
        'tensorflow', 'rapidfuzz', 'plotly'
    ]
    
    missing_packages = []
    present_packages = []
    
    for package in required_packages:
        try:
            __import__(package)
            present_packages.append(f"✅ {package}")
        except ImportError:
            missing_packages.append(f"❌ {package}")
    
    print("\n📋 Package Status:")
    for package_status in present_packages:
        print(f"   {package_status}")
    
    if missing_packages:
        print("\n⚠️ Missing Packages:")
        for package_status in missing_packages:
            print(f"   {package_status}")
        print("\n💡 Install missing packages with:")
        print("   pip install -r requirements.txt")
        return False
    else:
        print("\n✅ All required packages are installed!")
        return True

def test_import():
    """Test if the main app can be imported"""
    print("\n🔍 Testing App Import...")
    
    try:
        import app
        print("✅ app.py imports successfully")
        return True
    except Exception as e:
        print(f"❌ app.py import failed: {e}")
        return False

def test_dataset():
    """Test if dataset can be loaded"""
    print("\n📊 Testing Dataset...")
    
    try:
        import pandas as pd
        df = pd.read_csv("Dataset.csv")
        print(f"✅ Dataset loaded successfully: {len(df)} rows, {len(df.columns)} columns")
        
        # Check for required columns
        required_cols = ['prognosis', 'Specialist', 'Severity']
        missing_cols = [col for col in required_cols if col not in df.columns]
        
        if missing_cols:
            print(f"⚠️ Missing columns: {missing_cols}")
            return False
        else:
            print("✅ All required columns present")
            return True
            
    except Exception as e:
        print(f"❌ Dataset loading failed: {e}")
        return False

def test_streamlit():
    """Test if Streamlit can be launched"""
    print("\n🚀 Testing Streamlit Launch...")
    
    try:
        # Test streamlit command
        result = subprocess.run([sys.executable, "-m", "streamlit", "--version"], 
                              capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            print(f"✅ Streamlit is available: {result.stdout.strip()}")
            return True
        else:
            print(f"❌ Streamlit test failed: {result.stderr}")
            return False
    except subprocess.TimeoutExpired:
        print("⚠️ Streamlit test timed out")
        return False
    except Exception as e:
        print(f"❌ Streamlit test error: {e}")
        return False

def generate_launch_instructions():
    """Generate launch instructions"""
    print("\n" + "="*70)
    print("🚀 LAUNCH INSTRUCTIONS")
    print("="*70)
    
    print("\n📱 Method 1: Easy Launch (Recommended)")
    if os.name == 'nt':  # Windows
        print("   Double-click: run_app.bat")
        print("   OR run in command prompt: run_app.bat")
    else:  # Linux/Mac
        print("   Run in terminal: ./run_app.sh")
        print("   OR: chmod +x run_app.sh && ./run_app.sh")
    
    print("\n🐍 Method 2: Python Launcher")
    print("   python run_app.py")
    
    print("\n⚡ Method 3: Direct Streamlit")
    print("   streamlit run app.py")
    
    print("\n🌐 After Launch:")
    print("   1. Open your web browser")
    print("   2. Navigate to: http://localhost:8501")
    print("   3. The AI Medical Symptoms Analyzer will load")
    print("   4. Select your preferred language")
    print("   5. Enter symptoms or upload audio file")
    print("   6. Get instant AI-powered analysis!")
    
    print("\n💡 Tips:")
    print("   • Use Ctrl+C to stop the application")
    print("   • Refresh browser if page doesn't load")
    print("   • Check terminal for any error messages")
    print("   • Audio processing works best with clear recordings")

def main():
    """Main verification function"""
    print("🏥 AI MEDICAL SYMPTOMS ANALYZER - FINAL VERIFICATION")
    print("="*70)
    
    # Run all checks
    checks = [
        ("File Check", check_files),
        ("Dependency Check", check_dependencies),
        ("Import Test", test_import),
        ("Dataset Test", test_dataset),
        ("Streamlit Test", test_streamlit)
    ]
    
    passed_checks = 0
    total_checks = len(checks)
    
    for check_name, check_func in checks:
        try:
            if check_func():
                passed_checks += 1
        except Exception as e:
            print(f"❌ {check_name} failed with error: {e}")
    
    # Generate results
    print("\n" + "="*70)
    print("📊 VERIFICATION RESULTS")
    print("="*70)
    
    success_rate = (passed_checks / total_checks) * 100
    print(f"Checks Passed: {passed_checks}/{total_checks} ({success_rate:.1f}%)")
    
    if success_rate >= 80:
        print("\n🎉 SYSTEM IS READY FOR LAUNCH!")
        print("✅ All critical components are working")
        print("✅ Web interface is ready")
        print("✅ AI models are functional")
        print("✅ Dataset is accessible")
        
        generate_launch_instructions()
        
        print("\n🎯 FEATURES AVAILABLE:")
        print("✅ Disease Prediction (41 diseases)")
        print("✅ Symptom Analysis (132 symptoms)")
        print("✅ Specialist Recommendations")
        print("✅ Severity Assessment")
        print("✅ Multilingual Support (6 languages)")
        print("✅ Audio File Processing")
        print("✅ Modern Web Interface")
        
        print("\n⚠️ IMPORTANT DISCLAIMER:")
        print("This AI system is for informational purposes only.")
        print("Always consult with qualified healthcare providers")
        print("for proper medical diagnosis and treatment.")
        
        return True
        
    elif success_rate >= 60:
        print("\n⚠️ SYSTEM IS MOSTLY READY")
        print("✅ Core functionality works")
        print("⚠️ Some components may need attention")
        print("💡 You can still launch and test the system")
        
        generate_launch_instructions()
        return True
        
    else:
        print("\n❌ SYSTEM NEEDS ATTENTION")
        print("❌ Multiple issues detected")
        print("💡 Please resolve the issues above before launching")
        
        print("\n🔧 TROUBLESHOOTING:")
        print("1. Install missing dependencies: pip install -r requirements.txt")
        print("2. Ensure Dataset.csv is in the correct location")
        print("3. Check internet connection for model downloads")
        print("4. Try running: python comprehensive_test.py")
        
        return False

if __name__ == "__main__":
    success = main()
    
    if success:
        print("\n🎊 VERIFICATION COMPLETE - READY TO LAUNCH!")
        print("Choose your preferred launch method above and enjoy your AI Medical Symptoms Analyzer!")
    else:
        print("\n🔧 VERIFICATION FAILED - PLEASE FIX ISSUES")
        print("Resolve the issues above and run this script again.")

