#!/usr/bin/env python3
"""
Quick Test Script - Tests core functionality without full model loading
"""

import os
import sys

def test_basic_functionality():
    """Test basic functionality"""
    print("🧪 Quick Functionality Test")
    print("=" * 40)
    
    # Test 1: Check files
    print("1. Checking files...")
    required_files = ['app.py', 'Dataset.csv', 'requirements.txt']
    for file in required_files:
        if os.path.exists(file):
            print(f"   ✅ {file}")
        else:
            print(f"   ❌ {file}")
            return False
    
    # Test 2: Check dataset
    print("\n2. Checking dataset...")
    try:
        import pandas as pd
        df = pd.read_csv("Dataset.csv")
        print(f"   ✅ Dataset: {len(df)} rows, {len(df.columns)} columns")
        
        # Check key columns
        key_cols = ['prognosis', 'Specialist', 'Severity']
        for col in key_cols:
            if col in df.columns:
                print(f"   ✅ Column: {col}")
            else:
                print(f"   ❌ Missing column: {col}")
                return False
    except Exception as e:
        print(f"   ❌ Dataset error: {e}")
        return False
    
    # Test 3: Check imports
    print("\n3. Checking imports...")
    try:
        import streamlit as st
        print("   ✅ Streamlit")
        
        import pandas as pd
        print("   ✅ Pandas")
        
        import numpy as np
        print("   ✅ NumPy")
        
        import torch
        print("   ✅ PyTorch")
        
        import tensorflow as tf
        print("   ✅ TensorFlow")
        
        from transformers import AutoTokenizer
        print("   ✅ Transformers")
        
        import whisper
        print("   ✅ Whisper")
        
        from rapidfuzz import fuzz
        print("   ✅ RapidFuzz")
        
    except Exception as e:
        print(f"   ❌ Import error: {e}")
        return False
    
    # Test 4: Check app structure
    print("\n4. Checking app structure...")
    try:
        with open('app.py', 'r', encoding='utf-8') as f:
            content = f.read()
            
        required_functions = [
            'def load_models',
            'def enhanced_symptom_extraction',
            'def perfect_disease_prediction',
            'def translate_text',
            'def main'
        ]
        
        for func in required_functions:
            if func in content:
                print(f"   ✅ Function: {func}")
            else:
                print(f"   ❌ Missing function: {func}")
                return False
                
    except Exception as e:
        print(f"   ❌ App structure error: {e}")
        return False
    
    print("\n✅ All basic tests passed!")
    return True

def show_launch_options():
    """Show launch options"""
    print("\n🚀 LAUNCH OPTIONS:")
    print("=" * 40)
    
    print("\n📱 Option 1: Windows Batch File (Easiest)")
    print("   Double-click: run_app.bat")
    
    print("\n🐍 Option 2: Python Launcher")
    print("   python run_app.py")
    
    print("\n⚡ Option 3: Direct Streamlit")
    print("   streamlit run app.py")
    
    print("\n🌐 After launching:")
    print("   1. Open browser to: http://localhost:8501")
    print("   2. Select language")
    print("   3. Enter symptoms or upload audio")
    print("   4. Get AI analysis!")

def main():
    """Main function"""
    print("🏥 AI Medical Symptoms Analyzer - Quick Test")
    print("=" * 50)
    
    if test_basic_functionality():
        print("\n🎉 SYSTEM IS READY!")
        print("✅ All core components are working")
        print("✅ Web interface is ready")
        print("✅ AI models will load when you launch")
        
        show_launch_options()
        
        print("\n💡 Sample Test Cases:")
        print("   • 'I have chest pain and fast heart rate'")
        print("   • 'I have severe itching and skin rash'")
        print("   • 'I have stomach pain and acidity'")
        print("   • 'I have fever and headache'")
        
        print("\n⚠️ Remember:")
        print("   • This is for informational purposes only")
        print("   • Always consult healthcare professionals")
        print("   • Audio processing works best with clear recordings")
        
        return True
    else:
        print("\n❌ SYSTEM NEEDS ATTENTION")
        print("Please fix the issues above before launching")
        return False

if __name__ == "__main__":
    success = main()
    
    if success:
        print("\n🎊 READY TO LAUNCH!")
        print("Choose your preferred launch method above.")
    else:
        print("\n🔧 PLEASE FIX ISSUES FIRST")
        print("Run: pip install -r requirements.txt")
