#!/usr/bin/env python3
"""
Quick demo script for testing specific inputs
"""

import sys
sys.path.append('.')

def quick_demo():
    """Quick demo with pre-loaded results"""
    print('🏥 Medical AI Application - Quick Demo')
    print('=' * 50)
    
    # Sample inputs and their expected outputs
    samples = [
        {
            "input": "I have chest pain and fast heart rate, feeling anxious",
            "disease": "Heart Attack",
            "specialist": "Cardiologist", 
            "severity": "High",
            "confidence": "85%"
        },
        {
            "input": "I have severe itching and skin rash on my arms",
            "disease": "Fungal Infection",
            "specialist": "Dermatologist",
            "severity": "Low", 
            "confidence": "80%"
        },
        {
            "input": "I have stomach pain, acidity, and ulcers on my tongue",
            "disease": "GERD",
            "specialist": "Gastroenterologist",
            "severity": "Medium",
            "confidence": "75%"
        },
        {
            "input": "I feel tired, have high fever, and loss of appetite",
            "disease": "Common Cold",
            "specialist": "General Physician",
            "severity": "Medium",
            "confidence": "70%"
        },
        {
            "input": "I have been coughing and have difficulty breathing",
            "disease": "Pneumonia",
            "specialist": "Pulmonologist", 
            "severity": "High",
            "confidence": "85%"
        }
    ]
    
    print("📝 Sample Inputs and Expected Outputs:\n")
    
    for i, sample in enumerate(samples, 1):
        print(f"🧪 Sample {i}:")
        print(f"💬 Input: \"{sample['input']}\"")
        print(f"🎯 Disease: {sample['disease']}")
        print(f"👨‍⚕️ Specialist: {sample['specialist']}")
        print(f"⚠️ Severity: {sample['severity']}")
        print(f"📊 Confidence: {sample['confidence']}")
        print("-" * 50)
    
    print("\n🚀 To test with the actual application:")
    print("1. Run: streamlit run app.py")
    print("2. Copy any of the sample inputs above")
    print("3. Paste in the text area")
    print("4. Click 'Analyze Symptoms'")
    print("5. View the results!")
    
    print("\n💡 You can also try your own symptom descriptions!")
    print("   Just describe your symptoms in natural language.")

if __name__ == "__main__":
    quick_demo()

