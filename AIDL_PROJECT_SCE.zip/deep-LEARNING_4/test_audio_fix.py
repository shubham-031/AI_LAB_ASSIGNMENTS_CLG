#!/usr/bin/env python3
"""
Test script to verify audio processing fix
This script tests the audio processing functionality with the existing input1.mp3 file
"""

import os
import sys
import pandas as pd
import numpy as np
import torch
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM, AutoModelForTokenClassification, pipeline
from langdetect import detect
import whisper
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
import tensorflow as tf
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense, Dropout, BatchNormalization
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras import regularizers
from rapidfuzz import fuzz
import warnings
warnings.filterwarnings('ignore')

def load_models():
    """Load all AI models and data"""
    print("🏥 Loading AI models...")
    
    # Load NER model
    model_name = "HUMADEX/english_medical_ner"
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForTokenClassification.from_pretrained(model_name)
    ner = pipeline("ner", model=model, tokenizer=tokenizer, aggregation_strategy="simple")
    
    # Load translation model
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    nllb_model_name = "facebook/nllb-200-distilled-600M"
    translation_tokenizer = AutoTokenizer.from_pretrained(nllb_model_name)
    translation_model = AutoModelForSeq2SeqLM.from_pretrained(
        nllb_model_name,
        torch_dtype=torch.float32,
        device_map={"": device}
    )
    
    # Load Whisper model
    whisper_model = whisper.load_model("base")
    
    # Load dataset
    df = pd.read_csv("Dataset.csv")
    
    # Prepare data for model
    lb = LabelEncoder()
    df['prognosis'] = lb.fit_transform(df['prognosis'])
    
    X = df.drop(columns=['Specialist','prognosis', 'Severity'])
    y = df['prognosis']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=2)
    
    # Create and train model
    model = Sequential()
    model.add(Dense(64, activation='relu', input_dim=132))
    model.add(BatchNormalization())
    model.add(Dropout(0.5))
    model.add(Dense(32, activation='relu', kernel_regularizer=regularizers.l2(0.01)))
    model.add(Dropout(0.4))
    model.add(BatchNormalization())
    model.add(Dense(41, activation='softmax'))
    
    model.compile(loss='sparse_categorical_crossentropy', optimizer='Adam', metrics=['accuracy'])
    
    # Train model (simplified for demo)
    early_stop = EarlyStopping(monitor='val_accuracy', patience=3, restore_best_weights=True)
    model.fit(X_train, y_train, epochs=10, validation_data=(X_test, y_test), 
             callbacks=[early_stop], batch_size=64, verbose=0)
    
    return {
        'ner': ner,
        'whisper_model': whisper_model,
        'translation_tokenizer': translation_tokenizer,
        'translation_model': translation_model,
        'disease_model': model,
        'label_encoder': lb,
        'df': df,
        'X_train': X_train,
        'device': device
    }

def enhanced_symptom_extraction(text, ner_model):
    """Enhanced symptom extraction using multiple methods"""
    try:
        # Method 1: NER extraction
        entities = ner_model(text)
        ner_symptoms = [e['word'].strip() for e in entities if e['entity_group'] in ['PROBLEM', 'SYMPTOM', 'DISEASE']]
        
        # Method 2: Enhanced keyword-based extraction
        symptom_keywords = {
            'fever': ['fever', 'high_fever', 'mild_fever', 'temperature', 'hot'],
            'cough': ['cough', 'coughing', 'dry_cough'],
            'headache': ['headache', 'head_pain', 'migraine', 'head_ache'],
            'pain': ['pain', 'ache', 'sore', 'hurt', 'aching'],
            'stomach_pain': ['stomach_pain', 'abdominal_pain', 'belly_pain', 'stomach_ache'],
            'chest_pain': ['chest_pain', 'chest_discomfort', 'chest_ache', 'chest_hurt'],
            'back_pain': ['back_pain', 'spine_pain', 'back_ache'],
            'joint_pain': ['joint_pain', 'arthritis', 'joint_ache'],
            'fatigue': ['tired', 'fatigue', 'exhausted', 'weakness', 'tiredness'],
            'nausea': ['nausea', 'nauseous', 'sick', 'queasy'],
            'vomiting': ['vomiting', 'vomit', 'throwing_up'],
            'diarrhea': ['diarrhea', 'loose_stools', 'watery_stools'],
            'constipation': ['constipation', 'hard_stools'],
            'breathlessness': ['breathlessness', 'shortness_of_breath', 'difficulty_breathing', 'breathing_problems'],
            'fast_heart_rate': ['fast_heart_rate', 'palpitations', 'heart_racing', 'rapid_heartbeat', 'heart_beat', 'heartbeat'],
            'skin_rash': ['skin_rash', 'rash', 'skin_irritation', 'dermatitis'],
            'itching': ['itching', 'itchy', 'pruritus'],
            'swelling': ['swelling', 'swollen', 'edema'],
            'dizziness': ['dizziness', 'vertigo', 'lightheaded', 'dizzy'],
            'anxiety': ['anxiety', 'anxious', 'nervous', 'worried'],
            'sweating': ['sweating', 'sweat', 'perspiration'],
            'weakness': ['weakness', 'weak', 'feeling_weak'],
            'nodal_skin_eruptions': ['nodal_skin_eruptions', 'skin_eruptions', 'nodal_eruptions'],
            'acidity': ['acidity', 'acid_reflux', 'heartburn'],
            'ulcers_on_tongue': ['ulcers_on_tongue', 'tongue_ulcers', 'mouth_ulcers']
        }
        
        extracted_symptoms = []
        text_lower = text.lower()
        
        # Extract using keyword matching
        for category, keywords in symptom_keywords.items():
            for keyword in keywords:
                if keyword in text_lower:
                    if category == 'chest_pain':
                        extracted_symptoms.append('chest_pain')
                    elif category == 'fast_heart_rate':
                        extracted_symptoms.append('fast_heart_rate')
                    elif category == 'anxiety':
                        extracted_symptoms.append('anxiety')
                    else:
                        extracted_symptoms.append(keyword)
                    break
        
        # Add specific symptom detection
        if 'chest' in text_lower and ('pain' in text_lower or 'hurt' in text_lower or 'ache' in text_lower):
            extracted_symptoms.append('chest_pain')
        
        if ('heart' in text_lower and ('rate' in text_lower or 'beat' in text_lower or 'racing' in text_lower)) or 'palpitations' in text_lower:
            extracted_symptoms.append('fast_heart_rate')
        
        if 'anxious' in text_lower or 'anxiety' in text_lower or 'nervous' in text_lower:
            extracted_symptoms.append('anxiety')
        
        # Combine NER and keyword extraction
        all_symptoms = list(set(ner_symptoms + extracted_symptoms))
        
        return all_symptoms
        
    except Exception as e:
        print(f"Symptom extraction error: {e}")
        return []

def perfect_disease_prediction(extracted_symptoms, models):
    """Perfect disease prediction function with enhanced matching"""
    try:
        # Create feature vector
        num_features = 132
        x_sample = np.zeros(num_features, dtype=np.float32)
        
        # Enhanced symptom matching with multiple strategies
        symptom_indices = []
        matched_symptoms = []
        
        # Strategy 1: Direct fuzzy matching
        for i, col in enumerate(models['X_train'].columns):
            for sym in extracted_symptoms:
                similarity_scores = [
                    fuzz.partial_ratio(sym.lower(), col.lower()),
                    fuzz.ratio(sym.lower(), col.lower()),
                    fuzz.token_sort_ratio(sym.lower(), col.lower()),
                    fuzz.token_set_ratio(sym.lower(), col.lower())
                ]
                max_similarity = max(similarity_scores)
                
                if max_similarity > 65:  # Lower threshold for better matching
                    symptom_indices.append(i)
                    matched_symptoms.append((sym, col, max_similarity))
                    break
        
        # Strategy 2: Enhanced keyword mapping
        enhanced_keywords = {
            'fever': ['high_fever', 'mild_fever'],
            'cough': ['cough'],
            'headache': ['headache'],
            'pain': ['stomach_pain', 'joint_pain', 'chest_pain', 'back_pain', 'neck_pain'],
            'stomach_pain': ['stomach_pain', 'abdominal_pain'],
            'chest_pain': ['chest_pain'],
            'joint_pain': ['joint_pain', 'knee_pain', 'hip_joint_pain'],
            'back_pain': ['back_pain'],
            'tired': ['fatigue', 'lethargy', 'weakness'],
            'fatigue': ['fatigue'],
            'cold': ['cold_hands_and_feets'],
            'sore throat': ['throat_irritation', 'patches_in_throat'],
            'itching': ['itching', 'internal_itching'],
            'skin': ['skin_rash', 'nodal_skin_eruptions'],
            'vomiting': ['vomiting'],
            'nausea': ['nausea'],
            'diarrhea': ['diarrhoea'],
            'constipation': ['constipation'],
            'breathing': ['breathlessness'],
            'heart_rate': ['fast_heart_rate', 'palpitations'],
            'dizziness': ['dizziness'],
            'sweating': ['sweating'],
            'chills': ['chills', 'shivering'],
            'appetite': ['loss_of_appetite', 'increased_appetite'],
            'acidity': ['acidity'],
            'ulcers': ['ulcers_on_tongue'],
            'yellow': ['yellowish_skin', 'yellow_urine', 'yellowing_of_eyes'],
            'swelling': ['swelling_of_stomach', 'swollen_legs', 'swelling_joints'],
            'weight': ['weight_gain', 'weight_loss'],
            'mood': ['mood_swings', 'depression', 'anxiety'],
            'sleep': ['restlessness'],
            'vision': ['blurred_and_distorted_vision', 'visual_disturbances'],
            'urine': ['burning_micturition', 'spotting_ urination', 'dark_urine'],
            'muscle': ['muscle_wasting', 'muscle_weakness', 'muscle_pain'],
            'lymph': ['swelled_lymph_nodes'],
            'thyroid': ['enlarged_thyroid'],
            'nails': ['brittle_nails', 'small_dents_in_nails', 'inflammatory_nails']
        }
        
        # Apply keyword mapping
        for symptom in extracted_symptoms:
            for keyword, matches in enhanced_keywords.items():
                if keyword in symptom.lower():
                    for match in matches:
                        if match in models['X_train'].columns:
                            idx = list(models['X_train'].columns).index(match)
                            if idx not in symptom_indices:
                                symptom_indices.append(idx)
                                matched_symptoms.append((symptom, match, 100))
        
        # Set matched symptoms to 1
        for idx in symptom_indices:
            x_sample[idx] = 1.0
        
        x_sample = x_sample.reshape(1, -1).astype(np.float32)
        
        # Get prediction with confidence
        prediction = models['disease_model'].predict(x_sample, verbose=0)
        predicted_class = np.argmax(prediction)
        confidence = np.max(prediction)
        
        # Get top 3 predictions
        top3_indices = np.argsort(prediction[0])[-3:][::-1]
        top3_diseases = [(models['label_encoder'].classes_[i], prediction[0][i]) for i in top3_indices]
        
        # Get disease information
        prognosis_labels = models['label_encoder'].classes_
        predicted_prognosis = prognosis_labels[predicted_class]
        
        # Find specialist and severity
        disease_indices = models['df'].index[models['df']['prognosis'] == predicted_class]
        if len(disease_indices) > 0:
            first_index = disease_indices[0]
            specialist = models['df']['Specialist'].iloc[first_index]
            severity = models['df']['Severity'].iloc[first_index]
        else:
            specialist = "General Physician"
            severity = "Medium"
        
        return {
            'disease': predicted_prognosis,
            'specialist': specialist,
            'severity': severity,
            'confidence': confidence,
            'matched_symptoms': len(symptom_indices),
            'top3_predictions': top3_diseases,
            'symptom_matches': matched_symptoms
        }
        
    except Exception as e:
        print(f"Prediction error: {e}")
        return None

def live_voice_to_text(duration=50, fallback_file=None, models=None):
    """Convert voice to text using Whisper - matches notebook implementation"""
    if fallback_file:
        print("Using fallback audio file:", fallback_file)
        # Convert to absolute path
        audio_file = os.path.abspath(fallback_file)
        print(f"Full path: {audio_file}")
        
        # Check if file exists
        if not os.path.exists(audio_file):
            print(f"❌ File not found: {audio_file}")
            return None
    else:
        print("No fallback file provided")
        return None

    try:
        print("🎤 Transcribing audio with Whisper...")
        
        result = models['whisper_model'].transcribe(
            audio_file,
            language=None,
            task="transcribe",
            beam_size=8,
            temperature=0.7,
        )

        transcribed_text = result["text"].strip()
        detected_language = result.get("language", "unknown")

        print(f"🌐 Detected language: {detected_language}")
        print(f"📝 Transcribed text: '{transcribed_text}'")

        if not transcribed_text:
            return "I couldn't understand what you said. Please try again."

        return transcribed_text

    except Exception as e:
        print(f"❌ Whisper transcription error: {e}")
        return "Sorry, I couldn't transcribe the audio."

def main():
    """Main test function"""
    print("🧪 Testing Audio Processing Fix")
    print("=" * 50)
    
    # Check if input1.mp3 exists
    if not os.path.exists("input1.mp3"):
        print("❌ input1.mp3 not found in current directory")
        print("Please ensure input1.mp3 is in the same directory as this script")
        return
    
    print("✅ Found input1.mp3 file")
    
    try:
        # Load models
        models = load_models()
        print("✅ Models loaded successfully")
        
        # Test audio processing
        print("\n🎤 Testing Audio Processing...")
        transcribed_text = live_voice_to_text(fallback_file="input1.mp3", models=models)
        
        if transcribed_text and transcribed_text not in ["I couldn't understand what you said. Please try again.", "Sorry, I couldn't transcribe the audio."]:
            print(f"✅ Audio transcribed successfully!")
            print(f"📝 Transcribed text: {transcribed_text}")
            
            # Test symptom extraction
            print("\n🔍 Testing Symptom Extraction...")
            symptoms = enhanced_symptom_extraction(transcribed_text, models['ner'])
            print(f"✅ Extracted symptoms: {symptoms}")
            
            if symptoms:
                # Test disease prediction
                print("\n🎯 Testing Disease Prediction...")
                prediction_result = perfect_disease_prediction(symptoms, models)
                
                if prediction_result:
                    print(f"✅ Disease prediction successful!")
                    print(f"🎯 Predicted Disease: {prediction_result['disease']}")
                    print(f"👨‍⚕️ Recommended Specialist: {prediction_result['specialist']}")
                    print(f"⚠️ Severity Level: {prediction_result['severity']}")
                    print(f"📊 Confidence Score: {prediction_result['confidence']:.3f}")
                    print(f"🔍 Matched Symptoms: {prediction_result['matched_symptoms']}")
                    print(f"📋 Top 3 Predictions:")
                    for i, (disease, confidence) in enumerate(prediction_result['top3_predictions'], 1):
                        print(f"   {i}. {disease}: {confidence:.3f}")
                    print(f"🔗 Symptom Matches: {len(prediction_result['symptom_matches'])}")
                    
                    print("\n🎉 AUDIO PROCESSING FIX SUCCESSFUL!")
                    print("✅ Audio file processing works correctly")
                    print("✅ Transcription works")
                    print("✅ Symptom extraction works")
                    print("✅ Disease prediction works")
                    print("✅ Specialist recommendation works")
                    print("✅ Severity prediction works")
                else:
                    print("❌ Disease prediction failed")
            else:
                print("❌ No symptoms extracted from transcribed text")
        else:
            print("❌ Audio transcription failed")
            
    except Exception as e:
        print(f"❌ Error during testing: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()

