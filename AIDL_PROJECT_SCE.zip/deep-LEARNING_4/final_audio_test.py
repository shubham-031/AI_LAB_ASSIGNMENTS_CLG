#!/usr/bin/env python3
"""
Final Audio Test - Complete verification of the fixed audio processing
"""

import os
import sys
import tempfile
import shutil

def test_complete_audio_workflow():
    """Test the complete audio processing workflow"""
    print("🎯 FINAL AUDIO PROCESSING TEST")
    print("=" * 60)
    
    # Check if input1.mp3 exists
    if not os.path.exists("input1.mp3"):
        print("❌ input1.mp3 not found")
        return False
    
    print("✅ input1.mp3 found")
    
    try:
        # Import the fixed functions from app.py
        sys.path.append('.')
        from app import (
            load_audio_with_torchaudio, 
            live_voice_to_text, 
            enhanced_symptom_extraction,
            perfect_disease_prediction
        )
        
        # Load models
        print("📥 Loading models...")
        import whisper
        import torch
        from transformers import AutoTokenizer, AutoModelForSeq2SeqLM, AutoModelForTokenClassification, pipeline
        import pandas as pd
        from sklearn.preprocessing import LabelEncoder
        from sklearn.model_selection import train_test_split
        import tensorflow as tf
        from tensorflow.keras import Sequential
        from tensorflow.keras.layers import Dense, Dropout, BatchNormalization
        from tensorflow.keras.callbacks import EarlyStopping
        from tensorflow.keras import regularizers
        
        # Load NER model
        model_name = "HUMADEX/english_medical_ner"
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForTokenClassification.from_pretrained(model_name)
        ner = pipeline("ner", model=model, tokenizer=tokenizer, aggregation_strategy="simple")
        
        # Load Whisper model
        whisper_model = whisper.load_model("base")
        
        # Load dataset
        df = pd.read_csv("Dataset.csv")
        lb = LabelEncoder()
        df['prognosis'] = lb.fit_transform(df['prognosis'])
        X = df.drop(columns=['Specialist','prognosis', 'Severity'])
        y = df['prognosis']
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=2)
        
        # Create disease model
        disease_model = Sequential()
        disease_model.add(Dense(64, activation='relu', input_dim=132))
        disease_model.add(BatchNormalization())
        disease_model.add(Dropout(0.5))
        disease_model.add(Dense(32, activation='relu', kernel_regularizer=regularizers.l2(0.01)))
        disease_model.add(Dropout(0.4))
        disease_model.add(BatchNormalization())
        disease_model.add(Dense(41, activation='softmax'))
        disease_model.compile(loss='sparse_categorical_crossentropy', optimizer='Adam', metrics=['accuracy'])
        
        # Train model quickly
        early_stop = EarlyStopping(monitor='val_accuracy', patience=3, restore_best_weights=True)
        disease_model.fit(X_train, y_train, epochs=5, validation_data=(X_test, y_test), 
                         callbacks=[early_stop], batch_size=64, verbose=0)
        
        # Create models object
        models = {
            'whisper_model': whisper_model,
            'ner': ner,
            'disease_model': disease_model,
            'label_encoder': lb,
            'df': df,
            'X_train': X_train,
            'device': torch.device("cpu")
        }
        
        print("✅ All models loaded successfully")
        
        # Test complete workflow
        print("\n🔄 Testing Complete Audio Workflow...")
        
        # Step 1: Audio transcription
        print("\n1️⃣ Audio Transcription...")
        transcribed_text = live_voice_to_text(fallback_file="input1.mp3", models=models)
        
        if not transcribed_text or transcribed_text in ["I couldn't understand what you said. Please try again.", "Sorry, I couldn't transcribe the audio.", "Sorry, I couldn't load the audio file."]:
            print("❌ Audio transcription failed")
            return False
        
        print(f"✅ Audio transcribed: '{transcribed_text}'")
        
        # Step 2: Symptom extraction
        print("\n2️⃣ Symptom Extraction...")
        symptoms = enhanced_symptom_extraction(transcribed_text, models['ner'])
        
        if not symptoms:
            print("❌ No symptoms extracted")
            return False
        
        print(f"✅ Symptoms extracted: {symptoms}")
        
        # Step 3: Disease prediction
        print("\n3️⃣ Disease Prediction...")
        prediction = perfect_disease_prediction(symptoms, models)
        
        if not prediction:
            print("❌ Disease prediction failed")
            return False
        
        print(f"✅ Disease predicted: {prediction['disease']}")
        print(f"✅ Specialist: {prediction['specialist']}")
        print(f"✅ Severity: {prediction['severity']}")
        print(f"✅ Confidence: {prediction['confidence']:.3f}")
        
        # Step 4: Test with temporary file (web upload simulation)
        print("\n4️⃣ Web Upload Simulation...")
        
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as tmp_file:
            shutil.copy2("input1.mp3", tmp_file.name)
            tmp_file_path = tmp_file.name
        
        try:
            # Test complete workflow with temporary file
            transcribed_text2 = live_voice_to_text(fallback_file=tmp_file_path, models=models)
            
            if transcribed_text2 and transcribed_text2 not in ["I couldn't understand what you said. Please try again.", "Sorry, I couldn't transcribe the audio.", "Sorry, I couldn't load the audio file."]:
                symptoms2 = enhanced_symptom_extraction(transcribed_text2, models['ner'])
                prediction2 = perfect_disease_prediction(symptoms2, models)
                
                if prediction2:
                    print(f"✅ Web upload simulation successful!")
                    print(f"✅ Transcribed: '{transcribed_text2[:50]}...'")
                    print(f"✅ Symptoms: {symptoms2}")
                    print(f"✅ Disease: {prediction2['disease']}")
                    print(f"✅ Specialist: {prediction2['specialist']}")
                    print(f"✅ Severity: {prediction2['severity']}")
                else:
                    print("❌ Web upload simulation failed at prediction step")
                    return False
            else:
                print("❌ Web upload simulation failed at transcription step")
                return False
                
        finally:
            if os.path.exists(tmp_file_path):
                os.unlink(tmp_file_path)
        
        print("\n🎉 COMPLETE WORKFLOW TEST SUCCESSFUL!")
        return True
        
    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Main test function"""
    print("🏥 AI Medical Symptoms Analyzer - Final Audio Test")
    print("=" * 70)
    
    if test_complete_audio_workflow():
        print("\n🎊 AUDIO PROCESSING COMPLETELY FIXED!")
        print("=" * 70)
        print("✅ Audio transcription: WORKING")
        print("✅ Symptom extraction: WORKING")
        print("✅ Disease prediction: WORKING")
        print("✅ Specialist recommendation: WORKING")
        print("✅ Severity assessment: WORKING")
        print("✅ Web upload simulation: WORKING")
        print("✅ Complete workflow: WORKING")
        
        print("\n🚀 YOUR WEB INTERFACE IS READY!")
        print("=" * 70)
        print("✅ The audio processing issue has been completely resolved")
        print("✅ Your web interface will now work perfectly with audio files")
        print("✅ No FFmpeg installation required")
        print("✅ All functionality is working as expected")
        
        print("\n🎯 LAUNCH YOUR WEB APP NOW:")
        print("   streamlit run app.py")
        print("   Then test with audio file uploads!")
        
        print("\n💡 WHAT WAS FIXED:")
        print("   • Whisper now uses torchaudio instead of FFmpeg")
        print("   • Audio files are properly loaded and preprocessed")
        print("   • File paths are handled correctly")
        print("   • Complete workflow from audio to diagnosis works")
        
    else:
        print("\n❌ AUDIO PROCESSING TEST FAILED")
        print("Please check the error messages above")

if __name__ == "__main__":
    main()

