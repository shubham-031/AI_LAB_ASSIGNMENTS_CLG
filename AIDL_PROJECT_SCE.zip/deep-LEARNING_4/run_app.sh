#!/bin/bash

echo "🏥 AI Medical Symptoms Analyzer - Linux/Mac Launcher"
echo "=================================================="
echo

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed"
    echo "Please install Python 3.8+ from your package manager"
    exit 1
fi

echo "✅ Python found: $(python3 --version)"
echo

# Check if required files exist
if [ ! -f "app.py" ]; then
    echo "❌ app.py not found"
    echo "Please ensure you're in the correct directory"
    exit 1
fi

if [ ! -f "Dataset.csv" ]; then
    echo "❌ Dataset.csv not found"
    echo "Please ensure the dataset file is present"
    exit 1
fi

echo "✅ Required files found"
echo

# Check if pip is installed
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip3 is not installed"
    echo "Please install pip3"
    exit 1
fi

# Install dependencies if needed
echo "📦 Checking dependencies..."
if ! pip3 show streamlit &> /dev/null; then
    echo "Installing dependencies..."
    pip3 install -r requirements.txt
    if [ $? -ne 0 ]; then
        echo "❌ Failed to install dependencies"
        exit 1
    fi
fi

echo "✅ Dependencies ready"
echo

# Run the application
echo "🚀 Starting AI Medical Symptoms Analyzer..."
echo "📱 The application will open in your default web browser"
echo "🌐 URL: http://localhost:8501"
echo
echo "💡 Tips:"
echo "   - Use Ctrl+C to stop the application"
echo "   - Refresh the browser if the page doesn't load"
echo "   - Check this terminal for any error messages"
echo

python3 -m streamlit run app.py



